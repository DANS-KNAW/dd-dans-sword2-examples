all-mappings
============

This bags contains one or more examples of each [mapping rule](https://docs.google.com/spreadsheets/d/1G5YHSDg3a91nI9NgRjbz11iRFU9qgnNkde6K84j1NWI/).
The codes in the comments reference the rule identifiers in the spreadsheet.